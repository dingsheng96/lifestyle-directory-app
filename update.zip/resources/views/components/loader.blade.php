<div class="loading">
    <div class="card card-loader">
        <div class="card-body d-flex justify-content-center align-items-center flex-column">
            <div class="spinner-border text-purple" role="status"></div>
            <p class="mt-2 mb-0">Loading...</p>
        </div>
    </div>
</div>