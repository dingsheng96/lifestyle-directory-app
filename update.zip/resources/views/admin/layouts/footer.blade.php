<footer class="main-footer d-flex flex-md-row flex-column border-0">
    <div class="px-md-2">
        {!! __('labels.copyright') !!}
    </div>
</footer>