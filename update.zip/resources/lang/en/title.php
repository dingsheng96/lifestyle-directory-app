<?php

return [
    'create' => 'Create :module',
    'delete' => 'Delete :module',
    'edit' => 'Edit :module',
    'view' => 'View :module'
];
