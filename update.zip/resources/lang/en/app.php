<?php

return [

    'register_title_main' => 'Application',
    'register_form_title' => 'Application Form',
    'register_btn_submit' => 'Register',

    'login_title_main' => 'Sign in to start your session',
    'login_btn_forgot_password' => 'Forgot your password?',
    'login_btn_register_merchant' => 'Register as merchant',

    'verified' => 'User has been verified successfully!',
    'btn_resend_verification_email' => 'Resend Verification Email',
    'resend_verify' => 'User verification email has been resend!'
];
