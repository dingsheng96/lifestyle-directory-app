<?php

return [
    'title' => 'Errors'
];
